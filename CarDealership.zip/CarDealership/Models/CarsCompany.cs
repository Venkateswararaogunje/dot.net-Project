﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CarDealership.Models
{
    [Table("Car_Company")]
    public class CarsCompany
    {
        [Key]

        public int ID { get; set; }

        public string CompanyName { get; set; }

    }
}
