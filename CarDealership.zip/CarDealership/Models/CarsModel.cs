﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CarDealership.Models
{
    [Table("Car_Models_Details")]
    public class CarsModel
    {
       

        [Key]
        public int ID { get; set; }

        public string Name { get; set; }

        public int CompanyID { get; set; }

        public string ModelType { get; set; }
    }
}
