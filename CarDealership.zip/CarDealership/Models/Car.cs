﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CarDealership.Models
{
    [Table("Car_Details")]
    public class Car
    {
        [Key]
        public int ID { get; set; }

        public string Name { get; set; }

        public int ModelID { get; set; }

        public int  Price { get; set; }

        public string Color { get; set; }

        public int EngineCC { get; set; }

        
    }
}
