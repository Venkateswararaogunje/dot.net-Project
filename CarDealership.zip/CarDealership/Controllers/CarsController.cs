﻿using CarDealership.Models;
using CarDealership.Repository;
using Microsoft.AspNetCore.Mvc;

namespace CarDealership.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class CarsController : ControllerBase
    {
        private readonly ICarsRepository _car;
        public CarsController(ICarsRepository car)
        {
            _car = car;
            
        }
        [HttpGet]
        [Route("GetCars")]
        public ActionResult Get()
        {
            var cars = _car.GetCar();
            return Ok(cars);
        }
        [HttpGet]
        [Route("GetCarByID/{Id}")]
        public ActionResult GetCarById(int CarID)
        {
            var cars = _car.GetCarByID(CarID);
            return Ok(cars);
        }
        [HttpPost]
        [Route("AddCar")]
        public ActionResult Post(Car car)
        {
            
            if (ModelState.IsValid)
            {
                _car.UpdateCar(car);
                
                return RedirectToAction("Index");
            }
            return Ok("Added Successfully");
        }
        [HttpPut]
        [Route("UpdateCar")]
        public async Task<IActionResult> Put(Car car)
        {
            await _car.UpdateCar(car);
            return Ok("Updated Successfully");
        }
        [HttpDelete]
        //[HttpDelete("{id}")]
        [Route("DeleteCar")]
        public JsonResult Delete(int CarID)
        {
            _car.DeleteCar(CarID);
            return new JsonResult("Deleted Successfully");
        }
    }
}
