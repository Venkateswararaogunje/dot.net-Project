﻿using CarDealership.Models;
using CarDealership.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CarDealership.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarsCompanyController : ControllerBase
    {
        private readonly ICarsCompanyRepository _company;
        public CarsCompanyController(ICarsCompanyRepository company)
        {
            _company = company;
        }
        [HttpGet]
        [Route("GetCompanies")]
        public ActionResult Get()
        {
            var companies = _company.GetCompanies();
            return Ok(companies);
        }
        [HttpGet]
        [Route("GetCompanyByCompanyID/{ID}")]
        public ActionResult GetCompanyById(int ID)
        {
            var companies = _company.GetCompanyByCompanyID(ID);
            return Ok(companies);
        }
        [HttpPost]
        [Route("AddCompany")]
        public ActionResult Post(CarsCompany company)
        {

            if (ModelState.IsValid)
            {
                _company.UpdateCompany(company);
                return RedirectToAction("Index");
            }
            return Ok("Added Successfully");
        }
        [HttpPut]
        [Route("UpdateCompany")]
        public async Task<IActionResult> Put(CarsCompany company)
        {
            await _company.UpdateCompany(company);
            return Ok("Updated Successfully");
        }
        [HttpDelete]
        
        [Route("DeleteCompany")]
        public JsonResult Delete(int ID)
        {
            _company.DeleteCompany(ID);
            return new JsonResult("Deleted Successfully");
        }
    }
}
