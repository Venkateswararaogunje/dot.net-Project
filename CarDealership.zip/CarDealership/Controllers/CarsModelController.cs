﻿using CarDealership.Models;
using CarDealership.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CarDealership.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarsModelController : ControllerBase
    {
        private readonly ICarsModelRepository _model;
        public CarsModelController(ICarsModelRepository model)
        {
            _model = model;
        }
        [HttpGet]
        [Route("GetModels")]
        public ActionResult Get()
        {
            var models = _model.GetModels();
            return Ok(models);
        }
        [HttpGet]
        [Route("GetModelByID/{ID}")]
        public ActionResult GetModelById(int ID)
        {
            var models = _model.GetModelByModelID(ID);
            return Ok(models);
        }
        [HttpPost]
        [Route("AddModel")]
        public ActionResult Post(CarsModel model)
        {

            if (ModelState.IsValid)
            {
                _model.UpdateModel(model);
                
                return RedirectToAction("Index");
            }
            return Ok("Added Successfully");
        }
        [HttpPut]
        [Route("UpdateModel")]
        public async Task<IActionResult> Put(CarsModel model)
        {
            await _model.UpdateModel(model);
            return Ok("Updated Successfully");
        }
        [HttpDelete]
        //[HttpDelete("{id}")]
        [Route("DeleteModel")]
        public JsonResult Delete(int ID)
        {
            _model.DeleteModel(ID);
            return new JsonResult("Deleted Successfully");
        }
    }
}
