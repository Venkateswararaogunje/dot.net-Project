﻿using CarDealership.DataAccessLayer;
using CarDealership.Models;
using Microsoft.EntityFrameworkCore;

namespace CarDealership.Repository
{
    public class CarsRepository : ICarsRepository
    {
        private readonly CarDealershipContext _carDBContext;
        public CarsRepository(CarDealershipContext context)
        {
            _carDBContext = context;

        }
        public IEnumerable<Car> GetCar()
        {
            return _carDBContext.Cars.ToList();
        }

        public bool DeleteCar(int ID)
        {
            var car = _carDBContext.Cars.Find(ID);
            bool result;
            if (car != null)
            {
                _carDBContext.Entry(car).State = EntityState.Deleted;
                _carDBContext.SaveChanges();
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }

        public async Task<Car> UpdateCar(Car objCar)
        {
            _carDBContext.Entry(objCar).State = EntityState.Modified;
            await _carDBContext.SaveChangesAsync();
            return objCar;
        }
        public Car GetCarByID(int CarID)
        {
            return _carDBContext.Cars.Find(CarID);
        }

        public void InsertCar(Car objCar)
        {

            _carDBContext.Set<Car>().Add(objCar);


        }
    }
}
