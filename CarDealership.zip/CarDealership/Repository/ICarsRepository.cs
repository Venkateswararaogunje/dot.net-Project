﻿using CarDealership.Models;

namespace CarDealership.Repository
{
    public interface ICarsRepository
    {
        IEnumerable<Car> GetCar();

        Car GetCarByID(int CarID);
        void InsertCar(Car objCar);
        Task<Car> UpdateCar(Car objCar);
        bool DeleteCar(int CarID);

        
    }
}
