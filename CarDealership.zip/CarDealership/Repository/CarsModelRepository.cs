﻿using CarDealership.DataAccessLayer;
using CarDealership.Models;
using Microsoft.EntityFrameworkCore;

namespace CarDealership.Repository
{
    public class CarsModelRepository : ICarsModelRepository
    {

        private readonly CarDealershipContext _carDBContext;
        public CarsModelRepository(CarDealershipContext context)
        {
            _carDBContext = context;
        }

        public bool DeleteModel(int ID)
        {
            var model = _carDBContext.Models.Find(ID);
            bool result;
            if (model != null)
            {
                _carDBContext.Entry(model).State = EntityState.Deleted;
                _carDBContext.SaveChanges();
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }

       
        public CarsModel GetModelByModelID(int ID)
        {
            return _carDBContext.Models.Find(ID);
        }

        public IEnumerable<CarsModel> GetModels()
        {
            return _carDBContext.Models.ToList();
        }



        public void InsertModel(CarsModel objModel)
        {
            _carDBContext.Set<CarsModel>().Add(objModel);
        }

            public async Task<CarsModel> UpdateModel(CarsModel objModel)
        {
            _carDBContext.Entry(objModel).State = EntityState.Modified;
            await _carDBContext.SaveChangesAsync();
            return objModel;
        }

       
    }
}
