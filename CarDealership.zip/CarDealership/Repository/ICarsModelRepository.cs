﻿using CarDealership.Models;

namespace CarDealership.Repository
{
    public interface ICarsModelRepository
    {

        IEnumerable<CarsModel> GetModels();
        CarsModel GetModelByModelID(int ID);
        void InsertModel(CarsModel objModel);
        Task<CarsModel> UpdateModel(CarsModel objModel);
        bool DeleteModel(int ID);
        
    }
}
