﻿using CarDealership.Models;

namespace CarDealership.Repository
{
    public interface ICarsCompanyRepository
    {
        IEnumerable<CarsCompany> GetCompanies();
        CarsCompany GetCompanyByCompanyID(int ID);
        void InsertCompany(CarsCompany objCompany);
        Task<CarsCompany> UpdateCompany(CarsCompany objCompany);
        bool DeleteCompany(int ID);
        
    }
}
