﻿using CarDealership.DataAccessLayer;
using CarDealership.Models;
using Microsoft.EntityFrameworkCore;

namespace CarDealership.Repository
{
    public class CarsCompanyRepository : ICarsCompanyRepository
    {
        private readonly CarDealershipContext _carDBContext;
        public CarsCompanyRepository(CarDealershipContext context)
        {
            _carDBContext = context;
        }
        public bool DeleteCompany(int ID)
        {
            var company = _carDBContext.Companies.Find(ID);
            bool result;
            if (company != null)
            {
                _carDBContext.Entry(company).State = EntityState.Deleted;
                _carDBContext.SaveChanges();
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }

        public IEnumerable<CarsCompany> GetCompanies()
        {
            return _carDBContext.Companies.ToList();
        }

        public CarsCompany GetCompanyByCompanyID(int CompanyID)
        {
            return _carDBContext.Companies.Find(CompanyID);
        }

        public void InsertCompany(CarsCompany objCompany)
        {
            _carDBContext.Set<CarsCompany>().Add(objCompany);
        }

        public async Task<CarsCompany> UpdateCompany(CarsCompany objCompany)
        {
            _carDBContext.Entry(objCompany).State = EntityState.Modified;
            await _carDBContext.SaveChangesAsync();
            return objCompany;
        }

       
    }
}
