﻿using CarDealership.Models;
using Microsoft.EntityFrameworkCore;

namespace CarDealership.DataAccessLayer
{
    public class CarDealershipContext : DbContext
    {
        public CarDealershipContext(DbContextOptions<CarDealershipContext> options) : base(options) { }
        public DbSet<Car> Cars
        {
            get;
            set;
        }
        public DbSet<CarsModel> Models
        {
            get;
            set;
        }
        public DbSet<CarsCompany> Companies
        {
            get;
            set;
        }
    }
}
