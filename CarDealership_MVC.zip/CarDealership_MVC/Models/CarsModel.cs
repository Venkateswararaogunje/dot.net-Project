﻿namespace CarDealership_MVC.Models
{
    public class CarsModel
    {
        public int ID { get; set; }

        public string Name { get; set; }

        public int CompanyID { get; set; }

        public string ModelType { get; set; }
    }
}
