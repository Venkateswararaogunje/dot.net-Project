﻿namespace CarDealership_MVC.Models
{
    public class CarsCompany
    {
        public int ID { get; set; }

        public string CompanyName { get; set; }
    }
}
