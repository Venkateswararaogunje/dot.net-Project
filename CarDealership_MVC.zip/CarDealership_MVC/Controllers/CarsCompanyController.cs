﻿using CarDealership_MVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace CarDealership_MVC.Controllers
{
    public class CarsCompanyController : Controller
    {
        HttpClient client;
        HttpResponseMessage response;
        List<CarsCompany> Car3 = new List<CarsCompany>();
        public ActionResult GetCompanies()
        {
            client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:7085");
            response = client.GetAsync("api/CarsCompany/GetCompanies/").Result;
            var Cars = response.Content.ReadAsAsync<IEnumerable<CarsCompany>>().Result;
            foreach (var c3 in Cars)
            {
                CarsCompany C3 = new CarsCompany();
                C3.ID = c3.ID;
                C3.CompanyName = c3.CompanyName;
                

                Car3.Add(C3);
            }
            return View(Car3);
        }
    }
}
