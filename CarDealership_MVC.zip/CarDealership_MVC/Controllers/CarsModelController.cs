﻿using CarDealership_MVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace CarDealership_MVC.Controllers
{
    public class CarsModelController : Controller
    {
        HttpClient client;
        HttpResponseMessage response;
        List<CarsModel> Car2 = new List<CarsModel>();
        public ActionResult GetModels()
        {
            client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:7085");
            response = client.GetAsync("api/CarsModel/GetModels/").Result;
            var Cars = response.Content.ReadAsAsync<IEnumerable<CarsModel>>().Result;
            foreach (var c2 in Cars)
            {
                CarsModel C2 = new CarsModel();
                C2.ID = c2.ID;
                C2.Name = c2.Name;
                C2.CompanyID = c2.CompanyID;
                C2.ModelType = c2.ModelType;
                

                Car2.Add(C2);
            }
            return View(Car2);
        }
    }
}
