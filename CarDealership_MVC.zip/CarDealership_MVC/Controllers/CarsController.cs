﻿using CarDealership_MVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace CarDealership_MVC.Controllers
{
    public class CarsController : Controller
    {
        HttpClient client;
        HttpResponseMessage response;
        List<Cars> Car1 = new List<Cars>();
        public ActionResult GetCar()
        {
            client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:7085");
            response = client.GetAsync("api/Cars/GetCars/").Result;
            var Cars = response.Content.ReadAsAsync<IEnumerable<Cars>>().Result;
            foreach (var c in Cars)
            {
                Cars C1 = new Cars();
                C1.ID = c.ID;
                C1.Name = c.Name;
                C1.ModelID = c.ModelID;
                C1.Price = c.Price;
                C1.Color = c.Color;
                C1.EngineCC = c.EngineCC;

                Car1.Add(C1);
            }
            return View(Car1);
        }

        public ActionResult GetCarByID(int ID)
        {
            client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:7085");
            response = client.GetAsync("api/Cars/GetCarById/").Result;
            //if(ID > 0)
            //{
            //    Car1.Find(ID);
            //}
            return View(Car1);
        }
    }
}
