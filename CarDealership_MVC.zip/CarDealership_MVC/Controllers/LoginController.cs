﻿using Microsoft.AspNetCore.Mvc;

namespace CarDealership_MVC.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }
    }
}
